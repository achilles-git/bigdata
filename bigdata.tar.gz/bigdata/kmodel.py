from numpy import array
from math import sqrt
from pyspark import SparkContext
from pyspark.mllib.clustering import KMeans, KMeansModel
sc = SparkContext()
parsedData = sc.textFile("hdfs://localhost:54310/home/project/batting.csv").map(lambda line:line.split(",")).map(lambda line: array([float(line[5]),float(line[6])]))

Data = sc.textFile("/home/tilak/Desktop/big-data/clustering/files/BattingStats.csv")
parsedData	= Data.map(lambda line:line.split(",")).map(lambda line: array([float(line[4]),float(line[6]),float(line[8])])) #Runs,Avg,SR

clusters = KMeans.train(parsedData, 6, maxIterations=10, initializationMode="random")


#clusters.predict(array([39.3,131.43]))





































































predictions=clusters.predict(parsedData)

names = Data.map(lambda line:line.split(",")).map(lambda line:line[0])


names = names.coalesce(1)    # coalesce(numPartitions, shuffle=False)  Return a new RDD that is reduced into numPartitions partitions.
predictions = predictions.coalesce(1)

names_list = array(names.collect())
predictions_list = array(predictions.collect())
datardd = names.zip(predictions)
datardd.collect()

def toCSVLine(data):
  return ','.join(str(d) for d in data)

lines = datardd.map(toCSVLine)
lines.coalesce(1).saveAsTextFile("q")
