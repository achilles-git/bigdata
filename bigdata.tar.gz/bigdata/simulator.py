

import csv
import random

t1_bat_order = []
t1_bow_order = []
t2_bat_order = []
t2_bow_order = []
# tname = []
team_won_csv = ''
team1_won_counter = 0
team2_won_counter = 0
tied_counter = 0

discrete_list = [0, 1, 2, 3, 4, 6, 7]



# Extraction of squads from the CSV and storing them in respective lists
with open('/home/tilak/Desktop/bigdata/IPL 2018/new/kxpvscsk.csv', 'r') as f:
	match_reader = csv.reader(f)
	for row in match_reader:
		if (row[0] == 'team1' or row[0] ==  'team2'):
			team_won_csv = row[0]
		else:
			t1_bat_order.append(row[0])
			t1_bow_order.append(row[1])
			t2_bat_order.append(row[2])
			t2_bow_order.append(row[3])
	t1_bat_order = [x for x in t1_bat_order if x != '']
	t1_bow_order = [x for x in t1_bow_order if x != '']
	t2_bat_order = [x for x in t2_bat_order if x != '']
	t2_bow_order = [x for x in t2_bow_order if x != '']
	t1_bow_order = t1_bow_order[:5] # Restricting to 5 bowlers
	t2_bow_order = t2_bow_order[:5]

def cluster_number(batsman, bowler) :
	with open('BatsmenCluster.csv', 'r') as f:
		# print('batcluster opened')
		bat_cluster_reader = csv.reader(f)
		for row in bat_cluster_reader:
			if batsman == row[0]:
				curr_bat_cluster_num = row[14]
				# print(type(curr_bat_cluster_num))
			else:
				curr_bat_cluster_num=str(random.randint(0,9))


	with open('BowlerCluster.csv', 'r') as f:
		bow_cluster_reader = csv.reader(f)
		for row in bow_cluster_reader:
			if bowler == row[0]:
				curr_bow_cluster_num = row[13]
			else:
				curr_bow_cluster_num=str(random.randint(0,9))
	return curr_bat_cluster_num, curr_bow_cluster_num



def pvp_plist(batsman, bowler) :
	pvp_check = False
	with open('PvP.csv', 'r') as f:
		pvp_reader = csv.reader(f)
		for row in pvp_reader:
			if batsman == row[0] and bowler == row[1]:
				pvp_check = True
				probs_list1 = row
			break
				
	if pvp_check :		
		probs_list = list(map(float, probs_list1))
		probs_list = probs_list[2:8]
		return pvp_check,probs_list
	else :
		return pvp_check,None
	

def gvg_plist(bat_cluster_number, bowler_cluster_number) :
	with open('GvG.csv', 'r') as f:
		gvg_reader = csv.reader(f)
		for row in gvg_reader:
			if bat_cluster_number == row[0] and bowler_cluster_number == row[1]:
				probs_list1 = row[:-1]
				
	probs_list = list(map(float, probs_list1))
	
	probs_list = probs_list[2:]
	return probs_list



def random_pick(some_list, probabilities) :
	x = random.uniform(0,sum(probabilities))
	cumulative_probability = 0.0
	for item, item_probability in zip(some_list, probabilities):
		cumulative_probability += item_probability
		if x < cumulative_probability: break
	return it

def innings(bat_order, bow_order, inn) : 
	tot_wickets = 0
	m = 1 
	n = 0
	bow_index_order = [0,1,0,1,2,3,4,2,3,4,2,3,4,2,3,4,0,1,0,1]  
	x = bow_index_order[0]

	total_runs = 0
	k = -1

	for i in range(0,120) :
		if i%6 == 0 :
			k += 1
			x = bow_index_order[k]

			tmp_m = m
			m = n
			n = tmp_m

		curr_bat = bat_order[m]
		other_bat = bat_order[n] 
		curr_bow = bow_order[x]
		
		existent, pvp_p_list = pvp_plist(curr_bat, curr_bow)  
		if existent :
			prediction = random_pick(discrete_list, pvp_p_list)
		else :
			bat_c_num, bow_c_num = cluster_number(curr_bat, curr_bow)
			gvg_p_list = gvg_plist(bat_c_num, bow_c_num)
			prediction = random_pick(discrete_list, gvg_p_list)
		if prediction==0 or prediction==2 or prediction==4 or prediction==6: 
			total_runs+=prediction 

		
		elif prediction==1 or prediction==3:
			total_runs+=prediction
			tmp_m = m
			m = n
			n = tmp_m
		else:
			tot_wickets+=1
			m=max(m,n) + 1
			if m > 10 :
				break
		
		if inn == 2 and total_runs > first_innings_score :
			break
			

	if inn == 1 :
		global first_innings_score1
		first_innings_score1 = total_runs
				
	num_of_overs_played = str(int((i+1)/6)) + "." + str((i+1)%6)  
	return total_runs, str(total_runs)+"/"+str(tot_wickets)+" Overs : "+ num_of_overs_played



for i in range(0,30):

	first_innings_score, formatted_score1 = innings(t1_bat_order, t2_bow_order, 1)
	print ("Team 1 Score : " + formatted_score1)

	second_innings_score, formatted_score2 = innings(t2_bat_order, t1_bow_order, 2)
	print ("Team 2 Score : " + formatted_score2)

	if first_innings_score > second_innings_score :
		print ("Team 1 wins!")
		team1_won_counter+=1
	elif second_innings_score > first_innings_score :
		print ("Team 2 wins!")
		team2_won_counter+=1
	else :
		print ("Match Tied.")
		tied_counter+=1
		
if (team_won_csv == 'team1'):
	accuracy = ( float((team1_won_counter/30)) * 100)
	print ('Accuracy = ' + str(accuracy) + '%')
elif (team_won_csv == 'team2'):
	accuracy = ( float((team2_won_counter/30)) * 100)
	print ('Accuracy = ' + str(accuracy) + '%')
else:
	accuracy = ( float((tied_counter/30)) * 100)  
	print ('Accuracy = ' + str(accuracy) + '%')
